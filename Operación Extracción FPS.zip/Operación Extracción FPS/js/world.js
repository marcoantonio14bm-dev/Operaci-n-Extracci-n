
import * as THREE from 'three';
import { CONFIG } from './config.js';

export const obstacles = [];

export function createWorld(scene, renderer, manager) {
    // AMBIENTE
    scene.background = new THREE.Color(0x59666b);
    scene.fog = new THREE.Fog(0x59666b, 25, 120);

    // Iluminación ambiental
    scene.add(new THREE.AmbientLight(0xd0d0c5, 1.4));

    // Luz ambiental adicional para aclarar las sombras
    const hemiLight = new THREE.HemisphereLight(
        0xdce8f0,
        0x777064,
        0.8
    );
    scene.add(hemiLight);
    // ILUMINACIÓN PRINCIPAL
    const sun = new THREE.DirectionalLight(0xffe2bd, 2.0);

    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);

    Object.assign(sun.shadow.camera, {
        left: -55,
        right: 55,
        top: 55,
        bottom: -55,
        near: 1,
        far: 160
    });

    sun.shadow.bias = -0.0002;
    sun.shadow.normalBias = 0.03;

    scene.add(sun, sun.target);

    const aniso = renderer.capabilities.getMaxAnisotropy();
    // TEXTURAS
    const tex = (file, rx = 1, ry = 1) => {
        const t = new THREE.TextureLoader(manager).load(
            'assets/' + file
        );

        t.wrapS = t.wrapT = THREE.RepeatWrapping;
        t.repeat.set(rx, ry);
        t.anisotropy = aniso;
        t.colorSpace = THREE.SRGBColorSpace;

        return t;
    };

    // SUELO
    const floor = new THREE.Mesh(
        new THREE.PlaneGeometry(110, 150),
        new THREE.MeshStandardMaterial({
            map: tex('floor2.jpg', 110 / 6, 150 / 6),
            color: 0xaaa99e,
            roughness: 0.95,
            metalness: 0.02
        })
    );

    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, 0, -62.5);
    floor.receiveShadow = true;

    scene.add(floor);

    // MATERIALES
    const wallMat = new THREE.MeshStandardMaterial({
        map: tex('brick_wall2.jpg'),
        color: 0xaaa69b,
        roughness: 0.95,
        metalness: 0.02
    });

    const buildingMat = new THREE.MeshStandardMaterial({
        map: tex('brick_wall2.jpg'),
        color: 0x77736a,
        roughness: 1
    });

    const concreteMat = new THREE.MeshStandardMaterial({
        color: 0x99968c,
        roughness: 1
    });

    const TILE = 4;
    const H = 5;
    const T = 1;

    // CONSTRUCCIÓN DE PAREDES Y COLISIONES

    function addBox(w, h, d, x, z, mat = wallMat) {

        const g = new THREE.BoxGeometry(w, h, d);
        const uv = g.attributes.uv;

        const s = [
            [d, h], [d, h],
            [w, d], [w, d],
            [w, h], [w, h]
        ];

        for (let f = 0; f < 6; f++) {
            for (let i = 0; i < 4; i++) {
                const k = f * 4 + i;

                uv.setXY(
                    k,
                    uv.getX(k) * s[f][0] / TILE,
                    uv.getY(k) * s[f][1] / TILE
                );
            }
        }

        const m = new THREE.Mesh(g, mat);

        m.position.set(x, h / 2, z);
        m.castShadow = true;
        m.receiveShadow = true;

        scene.add(m);
        m.updateMatrixWorld(true);

        const o = {
            mesh: m,
            box: new THREE.Box3().setFromObject(m)
        };

        obstacles.push(o);

        return o;
    }

    const wallZ = (z, x0, x1, mat = wallMat) =>
        addBox(
            Math.abs(x1 - x0),
            H,
            T,
            (x0 + x1) / 2,
            z,
            mat
        );

    const wallX = (x, z0, z1, mat = wallMat) =>
        addBox(
            T,
            H,
            Math.abs(z1 - z0),
            x,
            (z0 + z1) / 2,
            mat
        );

    // MAPA: CALLEJÓNES

    wallZ(10, -50, 50);
    wallZ(-135, -50, 50);

    wallX(-50, 10, -135);
    wallX(50, 10, -135);

    // AVENIDA PRINCIPAL

    wallX(-9, 5, -18);
    wallX(9, 5, -18);

    wallX(-9, -30, -48);
    wallX(9, -30, -48);

    wallX(-9, -60, -78);
    wallX(9, -60, -78);

    wallX(-9, -90, -108);
    wallX(9, -90, -108);

    wallX(-9, -120, -135);
    wallX(9, -120, -135);

    //CALLE LATERAL IZQUIERDA

    wallX(-40, 10, -12);
    wallX(-40, -28, -52);
    wallX(-40, -68, -92);
    wallX(-40, -108, -135);


    wallX(-20, 10, -18);
    wallX(-20, -32, -48);
    wallX(-20, -62, -78);
    wallX(-20, -92, -108);
    wallX(-20, -122, -135);

    wallZ(-18, -40, -20);
    wallZ(-48, -40, -20);
    wallZ(-78, -40, -20);
    wallZ(-108, -40, -20);

    //CALLE LATERAL DERECHA

    wallX(40, 10, -12);
    wallX(40, -28, -52);
    wallX(40, -68, -92);
    wallX(40, -108, -135);

    wallX(20, 10, -18);
    wallX(20, -32, -48);
    wallX(20, -62, -78);
    wallX(20, -92, -108);
    wallX(20, -122, -135);

    wallZ(-18, 20, 40);
    wallZ(-48, 20, 40);
    wallZ(-78, 20, 40);
    wallZ(-108, 20, 40);

    //CALLEJONES IZQUIERDOS

    // Primer callejón

    wallZ(-12, -40, -30);
    wallX(-30, -12, -30);
    wallZ(-30, -30, -20);

    // Segundo callejón

    wallZ(-38, -40, -32);
    wallX(-32, -38, -62);
    wallZ(-62, -32, -20);

    // Tercer callejón

    wallZ(-68, -40, -30);
    wallX(-30, -68, -92);
    wallZ(-92, -30, -20);

    // Cuarto callejón

    wallZ(-98, -40, -32);
    wallX(-32, -98, -122);
    wallZ(-122, -32, -20);

    //CALLEJONES DERECHOS

    // Primer callejón

    wallZ(-12, 30, 40);
    wallX(30, -12, -30);
    wallZ(-30, 20, 30);

    // Segundo callejón

    wallZ(-38, 32, 40);
    wallX(32, -38, -62);
    wallZ(-62, 20, 32);

    // Tercer callejón

    wallZ(-68, 30, 40);
    wallX(30, -68, -92);
    wallZ(-92, 20, 30);

    // Cuarto callejón

    wallZ(-98, 32, 40);
    wallX(32, -98, -122);
    wallZ(-122, 20, 32);

    // 7. ZONA INFERIOR
    wallZ(-125, -40, -25);
    wallZ(-125, 25, 40);

    wallX(-25, -125, -135);
    wallX(25, -125, -135);

    // Pasaje central inferior

    wallX(-15, -112, -128);
    wallX(15, -112, -128);

    wallZ(-112, -15, 15);

    // ESCOMBROS

    const debrisMat = new THREE.MeshStandardMaterial({
        color: 0x99958b,
        roughness: 1
    });

    function debris(x, z, count = 5) {

        for (let i = 0; i < count; i++) {

            const w = 0.3 + Math.random() * 0.8;
            const h = 0.15 + Math.random() * 0.4;
            const d = 0.3 + Math.random() * 0.8;

            const mesh = new THREE.Mesh(
                new THREE.BoxGeometry(w, h, d),
                debrisMat
            );

            mesh.position.set(
                x + (Math.random() - 0.5) * 3,
                h / 2,
                z + (Math.random() - 0.5) * 3
            );

            mesh.rotation.y = Math.random() * Math.PI;
            mesh.castShadow = true;
            mesh.receiveShadow = true;

            scene.add(mesh);
        }
    }

    debris(-15, -15, 5);
    debris(15, -35, 6);
    debris(-15, -65, 7);
    debris(15, -85, 5);
    debris(-15, -115, 6);
    debris(15, -125, 5);

    // BARRILES

    const barrelMat = new THREE.MeshStandardMaterial({
        color: 0x655444,
        roughness: 0.85,
        metalness: 0.25
    });

    function barrel(x, z) {

        const mesh = new THREE.Mesh(
            new THREE.CylinderGeometry(
                0.45,
                0.45,
                1.2,
                12
            ),
            barrelMat
        );

        mesh.position.set(x, 0.6, z);
        mesh.castShadow = true;
        mesh.receiveShadow = true;

        scene.add(mesh);
    }

    barrel(-14, -25);
    barrel(14, -55);
    barrel(-14, -80);
    barrel(14, -105);
    barrel(-17, -125);

    //FAROLAS 

    const poleMat = new THREE.MeshStandardMaterial({
        color: 0x555751,
        roughness: 0.8,
        metalness: 0.5
    });

    const lampMat = new THREE.MeshStandardMaterial({
        color: 0xc49b65,
        emissive: 0xffa34d,
        emissiveIntensity: 1.8
    });

    function streetLamp(x, z) {

        // Poste

        const pole = new THREE.Mesh(
            new THREE.CylinderGeometry(0.08, 0.12, 5, 8),
            poleMat
        );

        pole.position.set(x, 2.5, z);
        pole.castShadow = true;
        pole.receiveShadow = true;

        scene.add(pole);

        // Brazo del farol

        const arm = new THREE.Mesh(
            new THREE.BoxGeometry(1.2, 0.1, 0.1),
            poleMat
        );

        arm.position.set(x + 0.5, 4.8, z);
        scene.add(arm);

        // Lámpara

        const lamp = new THREE.Mesh(
            new THREE.BoxGeometry(0.5, 0.2, 0.5),
            lampMat
        );

        lamp.position.set(x + 1, 4.7, z);
        scene.add(lamp);

        // Luz de la farola

        const light = new THREE.PointLight(
            0xffb45c,
            2.0,
            16
        );

        light.position.set(x + 1, 4.5, z);
        scene.add(light);

        // Colisión invisible del poste

        const collider = new THREE.Mesh(
            new THREE.BoxGeometry(0.5, 5, 0.5),
            new THREE.MeshBasicMaterial({
                visible: false
            })
        );

        collider.position.set(x, 2.5, z);
        scene.add(collider);

        collider.updateMatrixWorld(true);

        obstacles.push({
            mesh: collider,
            box: new THREE.Box3().setFromObject(collider)
        });
    }

    streetLamp(-15, -10);
    streetLamp(15, -40);
    streetLamp(-15, -70);
    streetLamp(15, -100);
    streetLamp(-15, -130);

    // PUERTA FINAL

    const gateMat = new THREE.MeshStandardMaterial({
        color: 0x663388,
        emissive: 0x7700ff,
        emissiveIntensity: 1
    });

    const gate = addBox(
        30,
        H,
        1.2,
        0,
        CONFIG.gateZ,
        gateMat
    );

    // FUNCIONES DEL ESCENARIO

    return {

        gate,

        followSun(p) {

            sun.position.set(
                p.x + 20,
                50,
                p.z + 20
            );

            sun.target.position.set(
                p.x,
                0,
                p.z
            );
        },

        openGate() {

            const index = obstacles.indexOf(gate);

            if (index !== -1) {
                obstacles.splice(index, 1);
            }

            gateMat.emissive.set(0x00aa33);
            gateMat.color.set(0x104010);
        }

    };
}
