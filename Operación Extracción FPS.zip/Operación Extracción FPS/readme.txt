1. Para ejedcutar el juego se debe hacer click en GoLive y automaticamente el juego iniciará.
2. En la pantalla de inicio te saldrán los comando para poder controlar al personaje.
3. Dar click en la pantalla para iniciar.
4. La misión será recolectar 3 muestras de plagas repartidas por el mapa mientras te asechan los infectados.
5. Si un zombie te atrapa es Game Over
6. Por el mapa habrán escudos de protección y munición adicional para ayudarte durante la misión.
7. Una vez obtenido las 3 muestras, se abrirá el punto de extracción para poder finalizar el juego.