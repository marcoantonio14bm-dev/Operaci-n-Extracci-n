
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

import { CONFIG } from './js/config.js';
import { createWorld, obstacles } from './js/world.js';
import { createPlayer } from './js/player.js';
import { createWeapons } from './js/weapons.js';

import {
    loadZombies,
    spawnHorde,
    buildNavGrid,
    shootZombies,
    updateZombies
} from './js/zombies.js';

import { ui } from './js/ui.js';

// =====================================
// ESCENA Y CÁMARA
// =====================================

const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(
    75,
    innerWidth / innerHeight,
    0.05,
    300
);

scene.add(camera);

const renderer = new THREE.WebGLRenderer({
    antialias: true
});

renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));

renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

document.getElementById('canvas-container').appendChild(renderer.domElement);

// =====================================
// ESTADO DEL JUEGO
// =====================================

let ready = false;
let state = 'menu';

const manager = new THREE.LoadingManager(() => {

    ready = true;
    ui.overlay('OPERACIÓN EXTRACCIÓN', 'Click para jugar');

});

ui.overlay('OPERACIÓN OPERACIÓN EXTRACCIÓN', 'Cargando…');

// =====================================
// CREACIÓN DEL MUNDO Y JUGADOR
// =====================================

const world = createWorld(scene, renderer, manager);

const player = createPlayer(camera);

const weapons = createWeapons(
    camera,
    manager,
    () => shootZombies(camera, obstacles, scene)
);

loadZombies(scene, manager);
buildNavGrid(obstacles);

camera.add(new THREE.PointLight(0xffffff, 0.6, 18));

// =====================================
// ESCUDO PROTECTOR
// =====================================

const SHIELD_DURATION = 10;

let shieldTime = 0;

const shieldLight = new THREE.PointLight(
    0xaaaaaa,
    0,
    8
);

camera.add(shieldLight);

// Indicador del escudo
const shieldHud = document.createElement('div');

shieldHud.textContent = 'ESCUDO: 10s';

Object.assign(shieldHud.style, {
    position: 'fixed',
    top: '80px',
    left: '50%',
    transform: 'translateX(-50%)',
    padding: '10px 22px',
    background: 'rgba(70, 70, 70, 0.9)',
    color: '#ffffff',
    border: '2px solid #aaaaaa',
    borderRadius: '8px',
    fontFamily: 'Arial, sans-serif',
    fontSize: '18px',
    fontWeight: 'bold',
    letterSpacing: '2px',
    textShadow: '0 0 8px #cccccc',
    boxShadow: '0 0 15px #888888',
    display: 'none',
    zIndex: '1000',
    pointerEvents: 'none'
});

document.body.appendChild(shieldHud);

// =====================================
// OBJETIVOS Y OBJETOS RECOGIBLES
// =====================================

const pickups = [];

let muestras = 0;
let gateOpening = false;

const need = CONFIG.muestra.length;

const objective = () => ui.objective(
    muestras < need
        ? `OBJETIVO: consigue las muestras de plaga (${muestras}/${need})`
        : 'Misión cumplida ¡Corre a la zona de extracción!'
);

objective();

// =====================================
// FUNCIÓN PARA CREAR OBJETOS
// =====================================

function makePickup(x, z, color, geo, onTake, beam = false) {

    const mat = new THREE.MeshStandardMaterial({
        color,
        emissive: color,
        emissiveIntensity: 0.8
    });

    const mesh = new THREE.Mesh(geo, mat);

    mesh.position.set(x, 0.9, z);
    mesh.castShadow = true;

    if (beam) {

        const b = new THREE.Mesh(
            new THREE.CylinderGeometry(0.12, 0.12, 8, 8),
            new THREE.MeshBasicMaterial({
                color,
                transparent: true,
                opacity: 0.25,
                fog: false
            })
        );

        b.position.y = 3.5;
        mesh.add(b);
    }

    scene.add(mesh);

    pickups.push({
        mesh,
        onTake
    });
}

// =====================================
// CARGADOR DE MODELOS GLB
// =====================================

const gltfLoader = new GLTFLoader(manager);

// =====================================
// MUESTRAS DE PLAGA GLB
// =====================================

gltfLoader.load(

    './assets/plaga.glb',

    (gltf) => {

        const cardModel = gltf.scene;

        // Calcular dimensiones
        const box = new THREE.Box3().setFromObject(cardModel);

        const center = box.getCenter(new THREE.Vector3());
        const minY = box.min.y;

        // Centrar modelo
        cardModel.position.set(
            -center.x,
            -minY,
            -center.z
        );

        // Sombras
        cardModel.traverse((child) => {

            if (child.isMesh) {
                child.castShadow = true;
                child.receiveShadow = true;
            }

        });

        // Crear una muestra por cada posición
        for (const k of CONFIG.muestra) {

            const grupo = new THREE.Group();

            const muestra = cardModel.clone(true);

            muestra.scale.set(0.3, 0.3, 0.3);

            grupo.add(muestra);

            grupo.position.set(
                k.pos[0],
                0.9,
                k.pos[1]
            );

            scene.add(grupo);

            pickups.push({

                mesh: grupo,

                onTake: () => {

                    // Generar horda
                    spawnHorde(
                        ...k.horde,
                        CONFIG.hordeSize
                    );

                    // Actualizar objetivo
                    muestras++;

                    ui.toast(
                        `Muestra (${muestras}/${need}) recogida — ¡VIENE UNA HORDA!`,
                        3500
                    );

                    objective();

                    // Desbloquear puerta
                    if (muestras === need) {

                        world.openGate();

                        buildNavGrid(obstacles);

                        gateOpening = true;

                        ui.toast(
                            '¡CORRE A LA ZONA DE EXTRACCIÓN! ¡VIENE UNA HORDA!',
                            4000
                        );

                    }

                }

            });

        }

    },

    undefined,

    (error) => {
        console.error('Error al cargar plaga.glb:', error);
    }

);

// CAJAS DE MUNICIÓN

gltfLoader.load(

    './assets/municion.glb',

    (gltf) => {

        const ammoModel = gltf.scene;

        // Calcular dimensiones
        const box = new THREE.Box3().setFromObject(ammoModel);

        const center = box.getCenter(new THREE.Vector3());
        const minY = box.min.y;

        // Centrar modelo
        ammoModel.position.set(
            -center.x,
            -minY,
            -center.z
        );

        // Sombras
        ammoModel.traverse((child) => {

            if (child.isMesh) {
                child.castShadow = true;
                child.receiveShadow = true;
            }

        });

        // Crear cajas en cada ubicación
        const ammoPositions = [
        [-25, -12],
        [20, -22],
        [-15, -38],
        [25, -48],
        [-28, -62],
        [15, -73],
        [-20, -88],
        [28, -98],
        [-12, -112],
        [22, -125]
];

for (const [x, z] of ammoPositions) {

            const grupo = new THREE.Group();

            const municion = ammoModel.clone(true);

            // Aumentar tamaño un 25 %
            municion.scale.set(4.25, 5.25, 5.25);

            grupo.add(municion);

            grupo.position.set(x, 0, z);

            scene.add(grupo);

            pickups.push({

                mesh: grupo,

                onTake: () => {

                    weapons.addAmmo();

                    ui.toast('Munición recogida');

                }

            });

        }

    },

    undefined,

    (error) => {
        console.error('Error al cargar municion.glb:', error);
    }

);

// ESCUDOS PROTECTORES

gltfLoader.load(

    './assets/escudo.glb',

    (gltf) => {

        const shieldModel = gltf.scene;

        // Centrar modelo
        const box = new THREE.Box3().setFromObject(shieldModel);

        const center = box.getCenter(new THREE.Vector3());

        shieldModel.position.sub(center);

        // Sombras
        shieldModel.traverse((child) => {

            if (child.isMesh) {
                child.castShadow = true;
                child.receiveShadow = true;
            }

        });

        // Cuatro ubicaciones de escudos
        const shieldPositions = [
            [0, -25],
            [5, -55],
            [0, -85],
            [5, -100]
        ];

        // Crear los cuatro escudos
        for (const [x, z] of shieldPositions) {

            const grupo = new THREE.Group();

            const escudo = shieldModel.clone(true);

            escudo.scale.set(1, 1, 1);

            grupo.add(escudo);

            grupo.position.set(x, 0.9, z);

            scene.add(grupo);

            pickups.push({

                mesh: grupo,

                onTake: () => {

                    // Activar o renovar protección
                    shieldTime = SHIELD_DURATION;

                    shieldLight.intensity = 1.8;

                    shieldHud.style.display = 'block';
                    shieldHud.style.opacity = '1';
                    shieldHud.textContent = 'ESCUDO: 10s';

                    ui.toast(
                        '¡ESCUDO RECOGIDO! Protección durante 10 segundos',
                        3000
                    );

                }

            });

        }

    },

    undefined,

    (error) => {
        console.error('Error al cargar escudo.glb:', error);
    }

);

// =====================================
// ZONA DE EXTRACCIÓN
// =====================================

const extraction = new THREE.Mesh(
    new THREE.BoxGeometry(6, 6, 6),

    new THREE.MeshBasicMaterial({
        color: 0x00ff66,
        transparent: true,
        opacity: 0.3
    })
);

extraction.position.set(...CONFIG.extractionPos);

scene.add(extraction);

// GAME OVER / MISIÓN COMPLETADA

function endGame(kind, title, sub) {

    if (state === 'over' || state === 'win') return;

    state = kind;

    ui.overlay(
        title,
        sub,
        kind === 'over' ? 'gameover' : 'win'
    );

    player.controls.unlock();

    setTimeout(
        () => location.reload(),
        kind === 'over' ? 3000 : 6000
    );
}

// =====================================
// CONTROLES
// =====================================

const overlayEl = document.getElementById('overlay');

overlayEl.addEventListener('click', () => {

    if (ready && (state === 'menu' || state === 'play')) {
        player.controls.lock();
    }

});

player.controls.addEventListener('lock', () => {

    state = 'play';

    ui.hideOverlay();

    weapons.refresh();

});

player.controls.addEventListener('unlock', () => {

    if (state === 'play') {
        ui.overlay('PAUSA', 'Click para continuar');
    }

});

addEventListener('keydown', (e) => {

    if (state !== 'play') return;

    if (e.code === 'Digit1') weapons.select(1);
    if (e.code === 'Digit2') weapons.select(2);
    if (e.code === 'KeyR') weapons.reload();

});

addEventListener('mousedown', (e) => {

    if (
        e.button === 0 &&
        state === 'play' &&
        player.controls.isLocked
    ) {
        weapons.fire();
    }

});

// REDIMENSIONAR VENTANA

addEventListener('resize', () => {

    camera.aspect = innerWidth / innerHeight;

    camera.updateProjectionMatrix();

    renderer.setSize(innerWidth, innerHeight);

});

// BUCLE PRINCIPAL

const clock = new THREE.Clock();

const flat = (a, b) => Math.hypot(
    a.x - b.x,
    a.z - b.z
);

(function loop() {

    requestAnimationFrame(loop);

    const dt = Math.min(clock.getDelta(), 0.05);
    const t = clock.elapsedTime;

    if (state === 'play' && player.controls.isLocked) {

        player.update(dt);
        weapons.update(dt);

        // ACTUALIZAR ESCUDO

        if (shieldTime > 0) {

            shieldTime -= dt;

            shieldHud.textContent =
                `ESCUDO: ${Math.ceil(Math.max(0, shieldTime))}s`;

            // Parpadeo en los últimos 3 segundos
            if (shieldTime <= 3) {

                shieldLight.intensity =
                    Math.sin(t * 12) > 0 ? 2.5 : 0.5;

                shieldHud.style.opacity =
                    Math.sin(t * 12) > 0 ? '1' : '0.5';

            }

            // Desactivar escudo
            if (shieldTime <= 0) {

                shieldTime = 0;

                shieldLight.intensity = 0;

                shieldHud.style.display = 'none';

                shieldHud.style.opacity = '1';

                ui.toast(
                    '¡El escudo se ha desactivado!',
                    2000
                );

            }

        }

        // ACTUALIZAR ZOMBIS

        const caught = updateZombies(
            dt,
            camera.position,
            obstacles
        );

        // Protección contra GAME OVER
        if (caught && shieldTime <= 0) {

            endGame(
                'over',
                'GAME OVER',
                'Un zombi te atrapó…'
            );

        }

        // RECOGER OBJETOS

        for (let i = pickups.length - 1; i >= 0; i--) {

            const p = pickups[i];

            // Los objetos solo giran
            p.mesh.rotation.y += dt * 2;

            // Comprobar proximidad
            if (flat(camera.position, p.mesh.position) < 1.5) {

                scene.remove(p.mesh);

                pickups.splice(i, 1);

                p.onTake();

            }

        }

        // ABRIR PUERTA

        if (gateOpening) {

            world.gate.mesh.position.y -= 3 * dt;

            if (world.gate.mesh.position.y < -3) {

                scene.remove(world.gate.mesh);

                gateOpening = false;

            }

        }

        // EXTRACCIÓN

        if (
            muestras === need &&
            flat(camera.position, extraction.position) < 4
        ) {

            endGame(
                'win',
                '¡MISIÓN COMPLETADA!',
                'Has llegado a la zona de extracción.'
            );

        }

    }

    world.followSun(camera.position);

    renderer.render(scene, camera);

})();
