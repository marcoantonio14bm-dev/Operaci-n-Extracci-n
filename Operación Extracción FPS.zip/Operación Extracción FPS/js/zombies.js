
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js';
import { CONFIG } from './config.js';

const Z = CONFIG.zombie;
const list = [];

const CS = 0.5;
const X0 = -50;
const Z0 = -140;
const NX = 200;
const NZ = 310;

const blocked = new Uint8Array(NX * NZ);
const dist = new Int32Array(NX * NZ);
const queue = new Int32Array(NX * NZ);

const ci = (x) => Math.floor((x - X0) / CS);
const cj = (z) => Math.floor((z - Z0) / CS);

const inGrid = (i, j) =>
    i >= 0 && j >= 0 && i < NX && j < NZ;

let lastCell = -1;

const D4 = [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1]
];

// CONSTRUIR REJILLA DE NAVEGACIÓN

export function buildNavGrid(obstacles) {
    blocked.fill(0);
    lastCell = -1;

    for (const obstacle of obstacles) {
        if (!obstacle.box) continue;

        const box = obstacle.box;

        const i0 = Math.max(
            0,
            ci(box.min.x - Z.radius)
        );

        const i1 = Math.min(
            NX - 1,
            ci(box.max.x + Z.radius)
        );

        const j0 = Math.max(
            0,
            cj(box.min.z - Z.radius)
        );

        const j1 = Math.min(
            NZ - 1,
            cj(box.max.z + Z.radius)
        );

        for (let j = j0; j <= j1; j++) {
            for (let i = i0; i <= i1; i++) {
                blocked[j * NX + i] = 1;
            }
        }
    }
}

// BUSCAR CELDA LIBRE MÁS CERCANA

function nearestFreeCell(i, j) {
    if (!inGrid(i, j)) return -1;

    const start = j * NX + i;

    if (!blocked[start]) return start;

    let best = -1;
    let bestDistance = Infinity;

    for (let y = 0; y < NZ; y++) {
        for (let x = 0; x < NX; x++) {
            const index = y * NX + x;

            if (blocked[index]) continue;

            const dx = x - i;
            const dy = y - j;
            const distance = dx * dx + dy * dy;

            if (distance < bestDistance) {
                bestDistance = distance;
                best = index;
            }
        }
    }

    return best;
}

// BFS: CALCULAR DISTANCIAS AL JUGADOR

function flood(px, pz) {
    const i = ci(px);
    const j = cj(pz);

    if (!inGrid(i, j)) return;

    const originalCell = j * NX + i;

    if (originalCell === lastCell) return;

    lastCell = originalCell;

    dist.fill(-1);

    const start = nearestFreeCell(i, j);

    if (start < 0) return;

    dist[start] = 0;

    let head = 0;
    let tail = 0;

    queue[tail++] = start;

    while (head < tail) {
        const current = queue[head++];

        const x = current % NX;
        const y = Math.floor(current / NX);

        const nextDistance = dist[current] + 1;

        for (const [dx, dy] of D4) {
            const a = x + dx;
            const b = y + dy;

            if (!inGrid(a, b)) continue;

            const next = b * NX + a;

            if (blocked[next]) continue;
            if (dist[next] >= 0) continue;

            dist[next] = nextDistance;
            queue[tail++] = next;
        }
    }
}

// OBTENER SIGUIENTE PUNTO DE CAMINO

function nextWaypoint(x, z, out) {
    const i = ci(x);
    const j = cj(z);

    if (!inGrid(i, j)) return false;

    const current = nearestFreeCell(i, j);

    if (current < 0) return false;

    const currentX = current % NX;
    const currentY = Math.floor(current / NX);

    let best = dist[current];

    if (best < 0) return false;

    let bx = -1;
    let by = -1;

    for (let dx = -1; dx <= 1; dx++) {
        for (let dy = -1; dy <= 1; dy++) {
            if (!dx && !dy) continue;

            const a = currentX + dx;
            const b = currentY + dy;

            if (!inGrid(a, b)) continue;

            const next = b * NX + a;

            if (blocked[next]) continue;

            const d = dist[next];

            if (d < 0) continue;

            // Evitar atravesar esquinas de paredes
            if (dx && dy) {
                const side1 = currentY * NX + a;
                const side2 = b * NX + currentX;

                if (blocked[side1] || blocked[side2]) {
                    continue;
                }
            }

            if (d < best) {
                best = d;
                bx = a;
                by = b;
            }
        }
    }

    if (bx < 0) return false;

    out.set(
        X0 + (bx + 0.5) * CS,
        0,
        Z0 + (by + 0.5) * CS
    );

    return true;
}

// COLISIONES

const zb = new THREE.Box3();
const zc = new THREE.Vector3();

const zs = new THREE.Vector3(
    Z.radius * 2,
    1.8,
    Z.radius * 2
);

const wallHit = (obstacles, x, z) => {
    zb.setFromCenterAndSize(
        zc.set(x, 0.9, z),
        zs
    );

    return obstacles.some(
        (o) => o.box && o.box.intersectsBox(zb)
    );
};

function slide(z, dx, dz, obstacles) {
    const p = z.root.position;

    if (!wallHit(obstacles, p.x + dx, p.z)) {
        p.x += dx;
    }

    if (!wallHit(obstacles, p.x, p.z + dz)) {
        p.z += dz;
    }
}

// DETECTAR LÍNEA DE VISIÓN
const ray = new THREE.Ray();
const eb = new THREE.Box3();

const tmp = new THREE.Vector3();
const hitPt = new THREE.Vector3();

function lineOfSight(a, b, obstacles) {
    ray.origin.set(a.x, 0.9, a.z);

    tmp.set(
        b.x - a.x,
        0,
        b.z - a.z
    );

    const len = tmp.length();

    if (len < 0.001) return true;

    ray.direction.copy(tmp).divideScalar(len);

    for (const o of obstacles) {
        if (!o.box) continue;

        eb.copy(o.box).expandByScalar(Z.radius);

        if (
            ray.intersectBox(eb, hitPt) &&
            hitPt.distanceTo(ray.origin) < len
        ) {
            return false;
        }
    }

    return true;
}

// CARGAR MODELO DE ZOMBI

let ctx = null;

export function loadZombies(scene, manager) {
    const loader = new GLTFLoader(manager);

    loader.load(
        'assets/zombie.glb',

        (gltf) => {
            const proto = gltf.scene;

            proto.updateMatrixWorld(true);

            const bb = new THREE.Box3().setFromObject(proto);

            const originalHeight = bb.max.y - bb.min.y;

            if (originalHeight <= 0) {
                console.error('El modelo zombie.glb tiene una altura inválida');
                return;
            }

            const scale = Z.height / originalHeight;
            const footY = -bb.min.y * scale;

            ctx = {
                scene,
                gltf,
                proto,
                scale,
                footY
            };

            CONFIG.zombieSpawns.forEach(([x, z]) => {
                spawnZombie(x, z);
            });

            console.log('Zombis cargados correctamente');
        },

        undefined,

        (error) => {
            console.error('Error cargando zombie.glb:', error);
        }
    );
}

// CREAR UN ZOMBIE

export function spawnZombie(x, zz, chase = false) {
    if (!ctx) return;

    const {
        scene,
        gltf,
        proto,
        scale,
        footY
    } = ctx;

    const clip = (name) =>
        THREE.AnimationClip.findByName(gltf.animations, name) ||
        gltf.animations[0] ||
        null;

    const model = SkeletonUtils.clone(proto);

    model.scale.setScalar(scale);
    model.position.y = footY;
    model.rotation.y = Z.yawOffset;

    // Copiar materiales y guardar su color original
    const mats = [];

    model.traverse((o) => {
        if (!o.isMesh) return;

        o.frustumCulled = false;

        o.material = Array.isArray(o.material)
            ? o.material.map((m) => m.clone())
            : o.material.clone();

        const materials = Array.isArray(o.material)
            ? o.material
            : [o.material];

        materials.forEach((m) => {
            if (m.emissive) {
                mats.push({
                    material: m,
                    original: m.emissive.clone()
                });
            }
        });
    });

    const root = new THREE.Group();

    root.add(model);
    root.position.set(x, 0, zz);

    scene.add(root);

    // Hitbox invisible
    const hitbox = new THREE.Mesh(
        new THREE.BoxGeometry(
            0.8,
            Z.height,
            0.8
        ),
        new THREE.MeshBasicMaterial({
            visible: false
        })
    );

    hitbox.position.y = Z.height / 2;

    root.add(hitbox);

    // Animaciones
    const mixer = new THREE.AnimationMixer(model);

    const idleClip = clip(Z.idle);
    const walkClip = clip(Z.walk);

    const idle = idleClip
        ? mixer.clipAction(idleClip)
        : null;

    const walk = walkClip
        ? mixer.clipAction(walkClip)
        : null;

    if (idle) idle.play();

    const zombie = {
        root,
        mixer,
        idle,
        walk,
        mats,
        hitbox,

        hp: Z.hits,
        alive: true,
        chasing: false,

        flash: 0,

        dir: new THREE.Vector3(0, 0, 1)
    };

    hitbox.userData.zombie = zombie;

    list.push(zombie);

    if (chase) {
        startChase(zombie);
    }
}

// CREAR HORDA DE ZOMBIS

export function spawnHorde(x, z, dir, n) {
    for (let i = 0; i < n; i++) {
        const px = x + dir * (i % 4) * 1.4;

        const pz =
            z + (Math.floor(i / 4) - 1.5) * 2.2;

        spawnZombie(px, pz, true);
    }
}

// INICIAR PERSECUCIÓN

function startChase(z) {
    if (z.chasing || !z.alive) return;

    z.chasing = true;

    if (z.walk) {
        z.walk.reset();
        z.walk.play();
    }

    if (z.idle && z.walk) {
        z.idle.crossFadeTo(z.walk, 0.3, false);
    } else if (z.idle) {
        z.idle.stop();
    }
}

// DISPARAR A LOS ZOMBIS

const raycaster = new THREE.Raycaster();

raycaster.far = 80;

export function shootZombies(camera, obstacles, scene) {
    raycaster.setFromCamera(
        { x: 0, y: 0 },
        camera
    );

    const wallMeshes = obstacles
        .filter((o) => o.mesh && o.mesh.isObject3D)
        .map((o) => o.mesh);

    const zombieHitboxes = list
        .filter((z) => z.alive)
        .map((z) => z.hitbox);

    const targets = [
        ...wallMeshes,
        ...zombieHitboxes
    ];

    const hits = raycaster.intersectObjects(
        targets,
        true
    );

    if (hits.length === 0) return;

    const hit = hits[0];

    const zombie = hit.object.userData.zombie;

    if (!zombie || !zombie.alive) return;

    zombie.hp--;
    zombie.flash = 0.12;

    startChase(zombie);

    if (zombie.hp <= 0) {
        zombie.alive = false;
        zombie.chasing = false;

        zombie.mixer.stopAllAction();

        scene.remove(zombie.root);
    }
}

// ACTUALIZAR ZOMBIES

const want = new THREE.Vector3();
const wp = new THREE.Vector3();

export function updateZombies(dt, player, obstacles) {
    if (!player) return false;

    let caught = false;

    for (const z of list) {
        if (!z.alive) continue;

        // Actualizar efecto de daño
        if (z.flash > 0) {
            z.flash -= dt;

            z.mats.forEach(({ material, original }) => {
                if (z.flash > 0) {
                    material.emissive.setHex(0xff0000);
                } else {
                    material.emissive.copy(original);
                }
            });
        }

        const p = z.root.position;

        const d = Math.hypot(
            player.x - p.x,
            player.z - p.z
        );

        // Actualizar animaciones
        if (z.chasing || d < 45) {
            z.mixer.update(dt);
        }

        // Detectar jugador
        if (!z.chasing && d < Z.detect) {
            startChase(z);
        }

        // Perseguir jugador
        if (z.chasing) {
            let tx = player.x;
            let tz = player.z;

            // Si hay pared, calcular ruta alternativa
            if (!lineOfSight(p, player, obstacles)) {
                flood(player.x, player.z);

                if (nextWaypoint(p.x, p.z, wp)) {
                    tx = wp.x;
                    tz = wp.z;
                }
            }

            // Calcular dirección
            want.set(
                tx - p.x,
                0,
                tz - p.z
            );

            if (want.lengthSq() > 0.001) {
                want.normalize();

                z.dir.lerp(
                    want,
                    Math.min(1, dt * 8)
                ).normalize();

                // Girar hacia el jugador
                z.root.lookAt(
                    p.x + z.dir.x,
                    p.y,
                    p.z + z.dir.z
                );

                // Desplazar sin atravesar paredes
                slide(
                    z,
                    z.dir.x * Z.speed * dt,
                    z.dir.z * Z.speed * dt,
                    obstacles
                );
            }
        }

        // Comprobar contacto con jugador
        if (d < Z.contact) {
            caught = true;
        }
    }

    // EVITAR QUE LOS ZOMBIS SE AMONTONEN

    for (let i = 0; i < list.length; i++) {
        for (let j = i + 1; j < list.length; j++) {
            const a = list[i];
            const b = list[j];

            if (!a.alive || !b.alive) continue;

            const dx =
                b.root.position.x - a.root.position.x;

            const dz =
                b.root.position.z - a.root.position.z;

            const dd = Math.hypot(dx, dz);

            if (dd > 0 && dd < Z.radius * 2) {
                const k =
                    (Z.radius * 2 - dd) / (2 * dd);

                slide(
                    a,
                    -dx * k,
                    -dz * k,
                    obstacles
                );

                slide(
                    b,
                    dx * k,
                    dz * k,
                    obstacles
                );
            }
        }
    }

    return caught;
}
